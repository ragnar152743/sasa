Ragnar Tree Realism Replant - Minecraft Java 26.1

Effet :
- Casse le bas d un arbre.
- Les logs au dessus tombent et donnent les items.
- Une pousse est replantee automatiquement selon le type de bois.
- Les feuilles restent et disparaissent naturellement.

Installation :
1) Mets ce ZIP dans :
   ~/ragnar mc/data/world/datapacks/
2) Redemarre le serveur :
   cd "$HOME/ragnar mc"
   docker compose restart
3) Verifie en jeu :
   /datapack list

Note :
- Si tu casses une maison en bois, le datapack peut casser les logs proches.
- Le sapling se pose pres de l item du log tombe.
