# Detection des nouveaux logs tombes en item.
execute as @e[type=item,tag=!rtr_checked] at @s if items entity @s contents #minecraft:logs run function ragnar_tree:item_check
tag @e[type=item,tag=!rtr_checked] add rtr_checked
