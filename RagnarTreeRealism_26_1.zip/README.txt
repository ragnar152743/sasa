Ragnar Tree Realism - Datapack Minecraft Java 26.1

Effet :
- Quand tu casses le bas d un arbre, les logs au-dessus se cassent aussi.
- Les logs tombent en items.
- Les feuilles restent et disparaissent naturellement.

Installation serveur Docker :
1) Mets ce ZIP dans :
   ~/ragnar mc/data/world/datapacks/
2) Redemarre le serveur :
   cd "$HOME/ragnar mc"
   docker compose restart
3) En jeu :
   /datapack list

Limites :
- Ce n est pas une vraie animation physique.
- Si tu construis une maison en logs et que tu casses un log porteur, le datapack peut casser les logs proches.
