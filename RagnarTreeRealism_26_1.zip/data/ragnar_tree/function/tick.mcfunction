# Detecte les nouveaux items logs au sol.
# Si un log vient d etre casse et qu il reste un tronc au dessus, l arbre tombe.
execute as @e[type=item,tag=!rtr_checked] at @s if items entity @s contents #minecraft:logs run function ragnar_tree:item_check
tag @e[type=item,tag=!rtr_checked] add rtr_checked
