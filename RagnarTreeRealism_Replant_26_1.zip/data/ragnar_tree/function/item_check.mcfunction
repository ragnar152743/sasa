# Replante automatiquement une pousse selon le type de log casse.
# Le sapling est pose pres de l item tombe, si le sol est compatible et que le bloc est libre.
execute if items entity @s contents minecraft:oak_log run function ragnar_tree:plant_oak
execute if items entity @s contents minecraft:stripped_oak_log run function ragnar_tree:plant_oak
execute if items entity @s contents minecraft:birch_log run function ragnar_tree:plant_birch
execute if items entity @s contents minecraft:stripped_birch_log run function ragnar_tree:plant_birch
execute if items entity @s contents minecraft:spruce_log run function ragnar_tree:plant_spruce
execute if items entity @s contents minecraft:stripped_spruce_log run function ragnar_tree:plant_spruce
execute if items entity @s contents minecraft:jungle_log run function ragnar_tree:plant_jungle
execute if items entity @s contents minecraft:stripped_jungle_log run function ragnar_tree:plant_jungle
execute if items entity @s contents minecraft:acacia_log run function ragnar_tree:plant_acacia
execute if items entity @s contents minecraft:stripped_acacia_log run function ragnar_tree:plant_acacia
execute if items entity @s contents minecraft:dark_oak_log run function ragnar_tree:plant_dark_oak
execute if items entity @s contents minecraft:stripped_dark_oak_log run function ragnar_tree:plant_dark_oak
execute if items entity @s contents minecraft:mangrove_log run function ragnar_tree:plant_mangrove
execute if items entity @s contents minecraft:stripped_mangrove_log run function ragnar_tree:plant_mangrove
execute if items entity @s contents minecraft:cherry_log run function ragnar_tree:plant_cherry
execute if items entity @s contents minecraft:stripped_cherry_log run function ragnar_tree:plant_cherry

playsound minecraft:block.wood.break block @a[distance=..16] ~ ~ ~ 0.6 0.8
particle minecraft:poof ~ ~0.5 ~ 0.4 0.4 0.4 0.02 8 force
execute positioned ~0 ~1 ~0 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~0 ~1 ~1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~0 ~1 ~-1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~1 ~1 ~0 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~1 ~1 ~1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~1 ~1 ~-1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~-1 ~1 ~0 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~-1 ~1 ~1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~-1 ~1 ~-1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~0 ~2 ~0 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~0 ~2 ~1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~0 ~2 ~-1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~1 ~2 ~0 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~1 ~2 ~1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~1 ~2 ~-1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~-1 ~2 ~0 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~-1 ~2 ~1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~-1 ~2 ~-1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
