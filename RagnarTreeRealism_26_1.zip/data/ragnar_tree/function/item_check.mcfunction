# Lance la chute depuis le premier log trouve au dessus / proche de l item.
playsound minecraft:block.wood.break block @a[distance=..16] ~ ~ ~ 0.6 0.8
particle minecraft:poof ~ ~0.5 ~ 0.4 0.4 0.4 0.02 8 force
execute positioned ~0 ~1 ~0 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~0 ~1 ~1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~0 ~1 ~-1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~1 ~1 ~0 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~1 ~1 ~1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~1 ~1 ~-1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~-1 ~1 ~0 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~-1 ~1 ~1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~-1 ~1 ~-1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~0 ~2 ~0 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~0 ~2 ~1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~0 ~2 ~-1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~1 ~2 ~0 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~1 ~2 ~1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~1 ~2 ~-1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~-1 ~2 ~0 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~-1 ~2 ~1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
execute positioned ~-1 ~2 ~-1 if block ~ ~ ~ #minecraft:logs run function ragnar_tree:fell
