# Replante oak_sapling au sol, pres du log casse.
execute if block ~ ~ ~ air if block ~ ~-1 ~ minecraft:grass_block run setblock ~ ~ ~ minecraft:oak_sapling
execute if block ~ ~ ~ air if block ~ ~-1 ~ minecraft:dirt run setblock ~ ~ ~ minecraft:oak_sapling
execute if block ~ ~ ~ air if block ~ ~-1 ~ minecraft:coarse_dirt run setblock ~ ~ ~ minecraft:oak_sapling
execute if block ~ ~ ~ air if block ~ ~-1 ~ minecraft:podzol run setblock ~ ~ ~ minecraft:oak_sapling
execute if block ~ ~ ~ air if block ~ ~-1 ~ minecraft:rooted_dirt run setblock ~ ~ ~ minecraft:oak_sapling
execute if block ~ ~ ~ air if block ~ ~-1 ~ minecraft:moss_block run setblock ~ ~ ~ minecraft:oak_sapling
execute if block ~ ~ ~ air if block ~ ~-1 ~ minecraft:mud run setblock ~ ~ ~ minecraft:oak_sapling
execute if block ~ ~ ~ air if block ~ ~-1 ~ minecraft:farmland run setblock ~ ~ ~ minecraft:oak_sapling
execute if block ~ ~-1 ~ air if block ~ ~-2 ~ minecraft:grass_block run setblock ~ ~-1 ~ minecraft:oak_sapling
execute if block ~ ~-1 ~ air if block ~ ~-2 ~ minecraft:dirt run setblock ~ ~-1 ~ minecraft:oak_sapling
execute if block ~ ~-1 ~ air if block ~ ~-2 ~ minecraft:coarse_dirt run setblock ~ ~-1 ~ minecraft:oak_sapling
execute if block ~ ~-1 ~ air if block ~ ~-2 ~ minecraft:podzol run setblock ~ ~-1 ~ minecraft:oak_sapling
execute if block ~ ~-1 ~ air if block ~ ~-2 ~ minecraft:rooted_dirt run setblock ~ ~-1 ~ minecraft:oak_sapling
execute if block ~ ~-1 ~ air if block ~ ~-2 ~ minecraft:moss_block run setblock ~ ~-1 ~ minecraft:oak_sapling
execute if block ~ ~-1 ~ air if block ~ ~-2 ~ minecraft:mud run setblock ~ ~-1 ~ minecraft:oak_sapling
execute if block ~ ~-1 ~ air if block ~ ~-2 ~ minecraft:farmland run setblock ~ ~-1 ~ minecraft:oak_sapling
